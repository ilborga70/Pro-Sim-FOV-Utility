# Changelog - Pro-Sim FOV Utility v3.0.0.0

## 🚀 Main Feature: Half-Inch Support
- **Enhanced Precision:** Introduced the ability to select screen sizes with **0.5-inch** increments (e.g., 24.5", 27.5", 31.5").
- **Dynamic UI:** The value label next to the slider now correctly displays decimals (e.g., `27.5''`).

## 🛠 Bug Fixes & Improvements
### 💾 Profile Saving System (JSON)
- **My_Profile_FOV.json Fix:** Resolved an issue where the profile saved the "raw" slider value (e.g., 55) instead of the actual inches (e.g., 27.5).
- **Backward Compatibility:** The loading system is now "smart": it automatically recognizes both old profiles (integers) and new ones (with decimals), adapting them to the new scale without errors.

### 📊 Image Report (PNG)
- **Graphic Report Update:** The "Save Image Report" function now prints the exact dimension with decimals in the `FOV_Results.png` file, avoiding rounding errors that could mislead the user.

### 🔧 Code Optimizations
- **GDI+ Resource Management:** Improved memory handling during FOV diagram drawing to prevent slowdowns after multiple calculations.
- **Robust Parsing:** Added error handling for the Ratio selector (Standard/16:9) to prevent crashes with custom configurations.

---
**Why this update is important:**
Many sim racers use monitors with 24.5" or 27.5" panels (common in modern gaming displays). Specifying support for "half-inches" is a key advantage for this utility compared to simpler FOV calculators that only accept whole numbers.