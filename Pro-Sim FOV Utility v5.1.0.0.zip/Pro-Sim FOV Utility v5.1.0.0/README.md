# Pro-Sim FOV Utility v5.1
## The FOV Calculator Professional Drivers Use to Win

Now with Motion Blur Compensation, built-in diagonal calculator, and interactive guide.

## 🆕 What's New in v5.1

### Embedded Image in Help & Monitor Calculator
- The diagonal calculator image is now embedded directly in the script using **Base64 encoding**.
- No more external URL dependencies — the image loads instantly and works completely offline.
- Improved reliability and startup speed for the help window.


### Motion Blur Compensation (-5%)
- Added a new checkbox in the input panel that reduces all calculated FOV values by 5%.
- Compensates for motion blur perception in sim racing.
- Affects all output values: AMS2, iRacing, DiRT, ACRally, Richard Burns Rally, rFactor, LMU, ACEVO, and the triple screen angle.
- State is saved and loaded with JSON profiles (backward compatible with v3.5 profiles).
- Included in the image report export.

### Integrated Help & Monitor Calculator
- Replaced the simple help window with a dual-panel interface accessible via the `?` button.
- **Left panel**: Built-in Monitor Calculator Pro that converts screen diagonal from cm to inches and calculates exact width/height based on aspect ratio.
- **Right panel**: Complete user guide with usage instructions and formulas.
- Monitor calculator supports multiple aspect ratios: `4:3`, `16:9`, `16:10`, `21:9`, `32:9`.
- Bilingual support: Italian and English with one-click language switching.
- A visual reference diagram is included in the calculator.

### Enhanced Image Report
- The "Save Image Report" feature now includes the Motion Blur Compensation status.
- Provides a clear indication of whether the -5% adjustment is active.

---

## 🔧 Improvements
- Help window size increased to accommodate the new dual-panel layout (820×640).
- Text in the help window no longer auto-selects on opening.
- Improved IE11 compatibility for the embedded WebBrowser control.
- All existing functionality is preserved without changes.

---

## 📦 Profile Management
- Save/load functionality now includes the new Motion Blur Compensation parameter.
- Existing v3.5 profiles load correctly with the new version.
- The Motion Blur field defaults to unchecked if it's missing from older profiles.

---

## 🖥️ System Requirements
- Windows 7/8/10/11
- PowerShell 5.1 or later
- .NET Framework 4.5 or later

---

## 🔒 Antivirus False Positives
Since the file was compiled using **Win-PS2EXE**, any alerts are due to the nature of the compiler wrapper.
Don't worry — the code has been reviewed by IT experts and has been found to be completely safe and clean.

> 🔗 **Virus Scan Report:** [Jotti's Malware Scan](https://virusscan.jotti.org/en-US/filescanjob/f3qmrhay3b)