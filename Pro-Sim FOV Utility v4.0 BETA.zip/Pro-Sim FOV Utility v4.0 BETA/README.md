**Changelog – Version 4.0 BETA with motion blur compensation and integrated help guide**

**New features:**

- **Motion Blur Compensation**  
  - Added a new checkbox “Motion Blur Compensation (-5%)” in the input panel.  
  - When enabled, all calculated FOV values (AMS2, iRacing, rFactor, etc.) and the triple screen angle are reduced by 5%.  
  - The compensation has been integrated into the `Calculate-FOV` function and applies to both the text display and the preview diagram.  
  - The new parameter is saved and loaded with JSON profiles (backward compatibility with previous profiles is guaranteed).  
  - The image report includes an indication of the compensation state.

- **Help button “?”**  
  - Added a small round button with the `?` symbol in the top-right corner of the main window.  
  - Clicking it opens a dialog window with a complete guide, explaining:  
  - How to use all controls (aspect ratio, size, distance, bezel, curvature, etc.).    
  - The practical meaning of the results and options (including the new motion blur compensation).